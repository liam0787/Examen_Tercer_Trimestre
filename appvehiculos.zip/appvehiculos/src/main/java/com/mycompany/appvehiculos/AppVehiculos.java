/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.appvehiculos;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class AppVehiculos {
    public static void main(String[] args) {
        // Crear lista de vehículos (Polimorfismo)
        ArrayList<Vehiculo> vehiculos = new ArrayList<>();
        
        // Instanciar vehículos iniciales
        try {
            vehiculos.add(new Coche("Toyota", "Corolla", 2020, 180.0));
            vehiculos.add(new Moto("Honda", "CBR", 2021, 200.0));
            vehiculos.add(new Bicicleta("Trek", "FX", 2022, 30.0));
            vehiculos.add(new Camion("Volvo", "FH16", 2019, 120.0));
            vehiculos.add(new Patinete("Xiaomi", "Mi Scooter", 2023, 25.0));
        } catch (VelocidadInvalidaException e) {
            System.out.println("Error al crear vehículo inicial: " + e.getMessage());
            return; // Terminar si hay error en la inicialización
        }

        // Crear Scanner para entrada del usuario
        Scanner scanner = new Scanner(System.in);
        int opcion = 0;

        do {
            // Mostrar menú
            System.out.println("\n=== Sistema de Vehiculos ===");
            System.out.println("1. Mostrar todos los vehiculos");
            System.out.println("2. Mostrar informacion de un Coche");
            System.out.println("3. Mostrar informacion de una Moto");
            System.out.println("4. Mostrar informacion de una Bicicleta");
            System.out.println("5. Mostrar informacion de un Camión");
            System.out.println("6. Mostrar informacion de un Patinete");
            System.out.println("7. Añadir nuevo vehiculo");
            System.out.println("8. Salir");
            System.out.print("Seleccione una opcion (1-8): ");

            // Leer opción del usuario con manejo de excepciones
            try {
                opcion = scanner.nextInt();
                scanner.nextLine(); // Limpiar buffer
            } catch (InputMismatchException e) {
                System.out.println("Error: Por favor, ingrese un número valido.");
                scanner.nextLine(); // Limpiar entrada inválida
                continue;
            }

            // Procesar opción con switch-case
            switch (opcion) {
                case 1:
                    // Mostrar todos los vehículos
                    System.out.println("\n=== Lista de Todos los Vehiculos ===");
                    if (vehiculos.isEmpty()) {
                        System.out.println("No hay vehiculos registrados.");
                    } else {
                        for (Vehiculo vehiculo : vehiculos) {
                            System.out.println(vehiculo);
                            System.out.print("Acción: ");
                            vehiculo.arrancar();
                            System.out.println("-------------------");
                        }
                    }
                    break;

                case 2:
                    // Mostrar Coche
                    boolean cocheEncontrado = false;
                    for (Vehiculo vehiculo : vehiculos) {
                        if (vehiculo instanceof Coche) {
                            System.out.println("\n=== Información del Coche ===");
                            System.out.println(vehiculo);
                            System.out.print("Acción: ");
                            vehiculo.arrancar();
                            System.out.println("-------------------");
                            cocheEncontrado = true;
                        }
                    }
                    if (!cocheEncontrado) {
                        System.out.println("No hay coches registrados.");
                    }
                    break;

                case 3:
                    // Mostrar Moto
                    boolean motoEncontrada = false;
                    for (Vehiculo vehiculo : vehiculos) {
                        if (vehiculo instanceof Moto) {
                            System.out.println("\n=== Información de la Moto ===");
                            System.out.println(vehiculo);
                            System.out.print("Acción: ");
                            vehiculo.arrancar();
                            System.out.println("-------------------");
                            motoEncontrada = true;
                        }
                    }
                    if (!motoEncontrada) {
                        System.out.println("No hay motos registradas.");
                    }
                    break;

                case 4:
                    // Mostrar Bicicleta
                    boolean bicicletaEncontrada = false;
                    for (Vehiculo vehiculo : vehiculos) {
                        if (vehiculo instanceof Bicicleta) {
                            System.out.println("\n=== Información de la Bicicleta ===");
                            System.out.println(vehiculo);
                            System.out.print("Acción: ");
                            vehiculo.arrancar();
                            System.out.println("-------------------");
                            bicicletaEncontrada = true;
                        }
                    }
                    if (!bicicletaEncontrada) {
                        System.out.println("No hay bicicletas registradas.");
                    }
                    break;

                case 5:
                    // Mostrar Camión
                    boolean camionEncontrado = false;
                    for (Vehiculo vehiculo : vehiculos) {
                        if (vehiculo instanceof Camion) {
                            System.out.println("\n=== Información del Camión ===");
                            System.out.println(vehiculo);
                            System.out.print("Acción: ");
                            vehiculo.arrancar();
                            System.out.println("-------------------");
                            camionEncontrado = true;
                        }
                    }
                    if (!camionEncontrado) {
                        System.out.println("No hay camiones registrados.");
                    }
                    break;

                case 6:
                    // Mostrar Patinete
                    boolean patineteEncontrado = false;
                    for (Vehiculo vehiculo : vehiculos) {
                        if (vehiculo instanceof Patinete) {
                            System.out.println("\n=== Información del Patinete ===");
                            System.out.println(vehiculo);
                            System.out.print("Acción: ");
                            vehiculo.arrancar();
                            System.out.println("-------------------");
                            patineteEncontrado = true;
                        }
                    }
                    if (!patineteEncontrado) {
                        System.out.println("No hay patinetes registrados.");
                    }
                    break;

                case 7:
                    // Añadir nuevo vehículo
                    System.out.println("\n=== Añadir Nuevo Vehículo ===");
                    System.out.println("Seleccione el tipo de vehículo:");
                    System.out.println("1. Coche");
                    System.out.println("2. Moto");
                    System.out.println("3. Bicicleta");
                    System.out.println("4. Camion");
                    System.out.println("5. Patinete");
                    System.out.print("Ingrese el número del tipo (1-5): ");
                    int tipoVehiculo = 0;
                    try {
                        tipoVehiculo = scanner.nextInt();
                        scanner.nextLine(); // Limpiar buffer
                    } catch (InputMismatchException e) {
                        System.out.println("Error: Por favor, ingrese un número valido para el tipo de vehículo.");
                        scanner.nextLine(); // Limpiar entrada inválida
                        continue;
                    }

                    System.out.print("Ingrese la marca del vehículo: ");
                    String marca = scanner.nextLine();
                    System.out.print("Ingrese el modelo del vehículo: ");
                    String modelo = scanner.nextLine();
                    System.out.print("Ingrese el año del vehículo: ");
                    int anio = 0;
                    try {
                        anio = scanner.nextInt();
                        scanner.nextLine(); // Limpiar buffer
                    } catch (InputMismatchException e) {
                        System.out.println("Error: Por favor, ingrese un año válido.");
                        scanner.nextLine(); // Limpiar entrada inválida
                        continue;
                    }
                    System.out.print("Ingrese la velocidad máxima (km/h): ");
                    double velocidadMaxima = 0.0;
                    try {
                        velocidadMaxima = scanner.nextDouble();
                        scanner.nextLine(); // Limpiar buffer
                    } catch (InputMismatchException e) {
                        System.out.println("Error: Por favor, ingrese una velocidad maxima valida.");
                        scanner.nextLine(); // Limpiar entrada inválida
                        continue;
                    }

                    try {
                        // Crear nuevo vehículo según el tipo seleccionado
                        switch (tipoVehiculo) {
                            case 1:
                                vehiculos.add(new Coche(marca, modelo, anio, velocidadMaxima));
                                System.out.println("Coche añadido: " + marca + " " + modelo);
                                break;
                            case 2:
                                vehiculos.add(new Moto(marca, modelo, anio, velocidadMaxima));
                                System.out.println("Moto añadida: " + marca + " " + modelo);
                                break;
                            case 3:
                                vehiculos.add(new Bicicleta(marca, modelo, anio, velocidadMaxima));
                                System.out.println("Bicicleta añadida: " + marca + " " + modelo);
                                break;
                            case 4:
                                vehiculos.add(new Camion(marca, modelo, anio, velocidadMaxima));
                                System.out.println("Camión añadido: " + marca + " " + modelo);
                                break;
                            case 5:
                                vehiculos.add(new Patinete(marca, modelo, anio, velocidadMaxima));
                                System.out.println("Patinete añadido: " + marca + " " + modelo);
                                break;
                            default:
                                System.out.println("Tipo de vehículo no válido. No se añadió ningún vehículo.");
                        }
                    } catch (VelocidadInvalidaException e) {
                        System.out.println("Error al añadir vehículo: " + e.getMessage());
                    }
                    break;

                case 8:
                    // Salir
                    System.out.println("¡Gracias por usar el Sistema de Vehículos!");
                    break;

                default:
                    System.out.println("Opción no válida. Por favor, seleccione una opción entre 1 y 8.");
            }
        } while (opcion != 8);

        // Cerrar Scanner
        scanner.close();
    }
}